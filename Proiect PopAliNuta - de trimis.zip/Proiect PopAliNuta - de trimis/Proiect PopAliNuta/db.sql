CREATE TABLE `Studenti`
(
 `id`       int NOT NULL ,
 `email`    varchar(45) NOT NULL ,
 `password` varchar(45) NOT NULL ,
 `nume`     varchar(45) NOT NULL ,

PRIMARY KEY (`id`)
);

SET FOREIGN_KEY_CHECKS = 0;