import Sequelize from 'sequelize';
import db from '../dbConfig.js';

const Student = db.define("studenti", {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull : false
    },

    email: {
        type: Sequelize.STRING,
        allowNull: false
    },

    password: {
        type: Sequelize.STRING,
        allowNull: false
    },

    nume: {
        type: Sequelize.STRING,
        allowNull: false
    }
})

export default Student;