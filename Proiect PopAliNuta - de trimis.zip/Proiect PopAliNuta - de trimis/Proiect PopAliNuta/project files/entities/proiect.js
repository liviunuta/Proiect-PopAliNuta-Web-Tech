import Sequelize from 'sequelize';
import db from '../dbConfig.js';

const Proiect = db.define("proiecte", {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull : false
    },

    nume: {
        type: Sequelize.STRING,
        allowNull: false
    },

    id_student: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        autoIncrement: false,
        allowNull : false
    },

    mjuriu5: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        allowNull : true
    },

    mjuriu4: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        allowNull : true
    },

    mjuriu3: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        allowNull : true
    },

    mjuriu2: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        allowNull : true
    },

    mjuriu1: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        allowNull : true
    },

    participant1: {
        type: Sequelize.STRING,
        allowNull: true
    },

    participant2: {
        type: Sequelize.STRING,
        allowNull: true
    },

    participant3: {
        type: Sequelize.STRING,
        allowNull: true
    },

    participant4: {
        type: Sequelize.STRING,
        allowNull: true
    },

    livrabil1: {
        type: Sequelize.STRING,
        allowNull: true
    },

    livrabil2: {
        type: Sequelize.STRING,
        allowNull: true
    },

    livrabil3: {
        type: Sequelize.STRING,
        allowNull: true
    },

    livrabil4: {
        type: Sequelize.STRING,
        allowNull: true
    },

    livrabil_final: {
        type: Sequelize.STRING,
        allowNull: true
    },

    creator: {
        type: Sequelize.STRING,
        allowNull: false
    }
})

export default Proiect;