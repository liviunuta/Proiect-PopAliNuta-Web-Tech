import Sequelize from 'sequelize';
import db from '../dbConfig.js';

const Nota = db.define("note", {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull : false
    },

    idProiect: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        allowNull : true
    },

    idJurat: {
        type: Sequelize.INTEGER,
        foreignKey: true,
        allowNull : true
    },

    nota: {
        type: Sequelize.INTEGER,
        allowNull: true
    }
})

export default Nota;