export const DB_USERNAME = 'root';
export const DB_PASSWORD = "123456";