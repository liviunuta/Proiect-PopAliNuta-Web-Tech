import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import path from 'path';
import {fileURLToPath} from 'url'
import mysql from 'mysql2/promise';

import { DB_USERNAME, DB_PASSWORD } from './Consts.js';
import db from './dbConfig.js';

import Professor from './entities/professor.js';
import Jurat from './entities/jurat.js';
import Student from './entities/student.js';
import Proiect from './entities/proiect.js';
import Nota from './entities/nota.js';





let app = express();
let router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname, 'public')))
app.use(bodyParser.json());
app.use(cors());
app.use(express.json())
app.use('', router);

let conn;

mysql.createConnection({
    user: DB_USERNAME,
    password:DB_PASSWORD
})
.then((connection) => {
    conn = connection
    return connection.query('CREATE DATABASE IF NOT EXISTS Projects');
})
.then(() => {
    return conn.end();
})
.catch((err) => {
    console.warn(err.stack);
})

/*
app = http.createServer(function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'})
    fs.readFile('index.html', function(error, data){
        if(error){
            res.writeHead(404)
            res.write('Error: File not found')
        }else{
            res.write(data)
        }
        res.end()
    })
})
*/



//Rute pentru partea de profesori
async function registerProfessor(professor){
    return await Professor.create(professor);
}
async function getProfessor(){
    return await Professor.findAll();
}
async function getProfessorById(id){
    return await Professor.findByPk(id);
}
router.route('/register_professor').post(async (req, res) => {
    try{
        res.json(await registerProfessor(req.body));
        res.status(201).json({message : 'created'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
    
})
router.route('/professors').get(async (req, res) => {
    try{
        res.json(await getProfessor());
        res.status(201).json({message : 'date afisate'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
})

router.route('/professors/:id').get(async (req, res) => {
    res.json(await getProfessorById(req.params.id));
})
//Aici se termina partea de requesturi pentru profesori





//Rute pentru partea de jurati
async function registerJurat(jurat){
    return await Jurat.create(jurat);
}
async function getJuriu(){
    return await Jurat.findAll();
}
async function getJuratById(id){
    return await Jurat.findByPk(id);
}
router.route('/register_jurat').post(async (req, res) => {
    try{
        res.json(await registerJurat(req.body));
        res.status(201).json({message : 'created'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
    
})
router.route('/juriu').get(async (req, res) => {
    try{
        res.json(await getJuriu());
        res.status(201).json({message : 'date afisate'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
})

router.route('/juriu/:id').get(async (req, res) => {
    res.json(await getJuratById(req.params.id));
})
//Aici se termina partea de requesturi pentru jurati





//Rute pentru partea de studenti
async function registerStudent(student){
    return await Student.create(student);
}
async function getStudenti(){
    return await Student.findAll();
}
async function getStudentById(id){
    return await Student.findByPk(id);
}
router.route('/register_student').post(async (req, res) => {
    try{
        res.json(await registerStudent(req.body));
        res.status(201).json({message : 'created'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
    
})
router.route('/studenti').get(async (req, res) => {
    try{
        res.json(await getStudenti());
        res.status(201).json({message : 'date afisate'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
})

router.route('/studenti/:id').get(async (req, res) => {
    res.json(await getStudentById(req.params.id));
})
//Aici se termina partea de requesturi pentru membru proiect





//Rute pentru partea de proiecte
async function createProiect(proiect){
    return await Proiect.create(proiect);
}
async function getProiecte(){
    return await Proiect.findAll();
}
async function getProiectById(id){
    return await Proiect.findByPk(id);
}
async function updateProiect(id, project){

    let updateEntity = await getProiectById(id);

    if (!updateEntity){
        console.log("There isn't a project with this id");
        return;
    }

    return updateEntity.update(project);
}
router.route('/add_proiect').post(async (req, res) => {
    try{
        res.json(await createProiect(req.body));
        res.status(201).json({message : 'created'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
    
})
router.route('/proiecte').get(async (req, res) => {
    try{
        res.json(await getProiecte());
        res.status(201).json({message : 'date afisate'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
})

router.route('/proiecte/:id').get(async (req, res) => {
    res.json(await getProiectById(req.params.id));
})

router.route('/edit_proiect/:id').put(async (req, res) => {
    res.json(await updateProiect(req.params.id, req.body));
})
//Aici se termina partea de requesturi pentru proiecte



//Rute pentru partea de note
async function createNota(nota){
    return await Nota.create(nota);
}
async function getNote(){
    return await Nota.findAll();
}
async function getNoteById(id){
    return await Nota.findByPk(id);
}
async function updateNota(id, nota){

    let updateEntity = await getNoteById(id);

    if (!updateEntity){
        console.log("There isn't a note with this id");
        return;
    }

    return updateEntity.update(nota);
}
router.route('/add_nota').post(async (req, res) => {
    try{
        res.json(await createNota(req.body));
        res.status(201).json({message : 'created'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
    
})
router.route('/note').get(async (req, res) => {
    try{
        res.json(await getNote());
        res.status(201).json({message : 'date afisate'})
    }catch{
        res.status(500).json({message : 'server error'})
    }
})

router.route('/note/:id').get(async (req, res) => {
    res.json(await getNoteById(req.params.id));
})

router.route('/edit_note/:id').put(async (req, res) => {
    res.json(await updateNota(req.params.id, req.body));
})


//Aici se termina partea de requesturi pentru proiecte



let port = process.env.PORT || 8000;
app.listen(port);
console.log(`API is running at ${port}`);