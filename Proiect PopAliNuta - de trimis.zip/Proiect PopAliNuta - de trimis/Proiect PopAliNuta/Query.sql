INSERT INTO `project`(ProjectId,ProjectName,ProjectAddress) VALUES (1,'test','acasa');
